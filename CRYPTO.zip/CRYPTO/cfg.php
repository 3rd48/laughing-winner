<?php

/* data mining */

$sign = "qyu2Xl4e97E4Jqqv4rdYDIM1be/Z06bgbVBPkbTmB/QhEUTBKpEl6/m6OhuEXqU3GvJQGQCuxIqs39He";
$auth = "Bearer gAAAAABgfDoa4FDZPeyEThQ1XSJpCIjl2HblMnNNYAj7GLIVLBnsLP7sGVU-fmhu71ejCy63I3y_jScWu-uxK2p1FoQg79rSjg==";

/* data email */

$sign1 = "AM90BWHFz29usbBCMu1WkfRrDmA3mfmJ68zr6CV6sqNTDVRg+p+NfX4ICt2xCtzVAGGfUR0v1VayxmYk";
$auth1 = "Bearer gAAAAABgfDovkK9XGFX2E02x1JHE2n_TtsffOQA94sH9fTRloKGAMjaF2Ii_hQPMSJRem3gf1exd7wRImDS75eju20eYJT0y7Q==";


/* cookie */

$user_agent = "Mozilla/5.0 (Linux; Android 10; SM-A107F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.114 Mobile Safari/537.36";
$ct_ts = "1618754095";
$token = "BTXJrbqMc5PncpHza7kpDRsfYV11KD8JSoalQQPTzfpV2sOJAHLTpe7t73w5fKpO";
$session = "6hrm4thv04nugctd460hup1pehmuq8h5";



?>
